'use strict';

window.StudioStorage = (() => {
    const $ = id => document.getElementById(id);
    let store, actions, busy = false, request = 0;
    function size(bytes) {
        if (!Number.isFinite(bytes) || bytes < 0) return 'Unavailable';
        const units = ['B', 'KiB', 'MiB', 'GiB', 'TiB']; let unit = 0;
        while (bytes >= 1024 && unit < units.length - 1) { bytes /= 1024; unit++; }
        return `${bytes.toLocaleString(undefined, { maximumFractionDigits: unit ? 1 : 0 })} ${units[unit]}`;
    }
    async function perform(task) {
        if (busy) return;
        busy = true; $('storage-feedback').textContent = '';
        $('studio-storage').setAttribute('aria-busy', 'true');
        try { await task(); }
        catch (e) { $('storage-feedback').textContent = e.message || String(e); }
        finally { busy = false; $('studio-storage').removeAttribute('aria-busy'); }
    }
    function button(label, task, danger = false) {
        const el = document.createElement('button'); el.className = 'dash-btn' + (danger ? ' danger' : '');
        el.textContent = label; el.onclick = () => perform(task); return el;
    }
    async function refresh() {
        const version = ++request;
        const [items, estimate, persisted, assets] = await Promise.all([
            store.usage(), Promise.resolve().then(() => navigator.storage?.estimate?.()).catch(() => null),
            Promise.resolve().then(() => navigator.storage?.persisted?.()).catch(() => undefined), store.listAssets()
        ]);
        if (version !== request) return;
        const available = Number.isFinite(estimate?.quota) && estimate.quota > 0 && Number.isFinite(estimate?.usage) && estimate.usage >= 0;
        $('storage-usage').textContent = available
            ? `${size(estimate.usage)} used of ${size(estimate.quota)} allowed · about ${size(Math.max(0, estimate.quota - estimate.usage))} available`
            : 'This browser does not provide a storage estimate. Your saved games are listed below.';
        $('storage-meter').hidden = !available;
        if (available) $('storage-meter').value = Math.min(1, estimate.usage / estimate.quota);
        $('portable-storage-status').textContent = persisted === true ? 'Persistent storage is on. Keep ZIP backups too.'
            : persisted === false ? 'Storage can be cleared by the browser. Keep a ZIP backup of games you want to keep.' : 'Persistent storage status is unavailable. Keep ZIP backups.';
        $('storage-assets-usage').textContent = `${assets.length} library assets · ${size(assets.reduce((total, asset) => total + asset.size, 0))} of original files`;
        const target = $('storage-projects'); target.replaceChildren();
        if (!items.length) { const empty = document.createElement('p'); empty.textContent = 'No games saved yet. Create a game or restore a ZIP backup.'; target.append(empty); }
        for (const item of items.sort((a, b) => b.updatedAt - a.updatedAt)) {
            const row = document.createElement('article'); row.className = 'storage-project'; row.dataset.projectId = item.id;
            const title = document.createElement('h4'); title.textContent = item.name;
            const detail = document.createElement('p'); detail.className = 'storage-hint';
            detail.textContent = `${size(item.bytes)} in ${item.fileCount} files · ${item.snapshotCount} snapshots (${size(item.snapshotBytes)}) · saved ${new Date(item.updatedAt).toLocaleString()}`;
            const controls = document.createElement('div'); controls.className = 'storage-actions';
            controls.append(button('Open game', async () => { await actions.open(item.id); $('studio-storage').close(); }),
                button('Download ZIP', async () => { await actions.download(item.id); $('storage-feedback').textContent = 'ZIP downloaded. Restore it here or from My Games → Import ZIP.'; }),
                button('Delete game', async () => {
                    if (!confirm(`Delete “${item.name}” and its ${item.snapshotCount} snapshots from this browser? Download a ZIP first if you want to keep the game. This cannot be undone.`)) return;
                    await actions.remove(item); await refresh(); $('storage-feedback').textContent = `Deleted “${item.name}”.`;
                }, true));
            row.append(title, detail, controls); target.append(row);
        }
    }
    async function open() {
        const dialog = $('studio-storage'); if (dialog.open) return;
        dialog.showModal();
        await perform(async () => {
            try { await actions.save(); } catch (e) { $('storage-feedback').textContent = e.message + ' You can still download your open draft.'; }
            await refresh();
        });
    }
    function init(database, callbacks) {
        store = database; actions = callbacks;
        for (const id of ['header-storage-btn', 'portable-storage-open']) { $(id).disabled = false; $(id).onclick = open; }
        $('storage-close').onclick = () => { if (!busy) $('studio-storage').close(); };
        $('studio-storage').addEventListener('cancel', event => { if (busy) event.preventDefault(); });
        $('storage-refresh').onclick = () => perform(refresh);
        $('storage-assets').onclick = () => { if (!busy) { $('studio-storage').close(); actions.assets(); } };
        $('storage-import').onclick = () => { if (!busy) { $('studio-storage').close(); $('portable-zip-input').click(); } };
        $('portable-persist').onclick = () => perform(async () => {
            const granted = await navigator.storage?.persist?.(); await refresh();
            $('storage-feedback').textContent = granted ? 'Persistent storage granted. Keep ZIP backups too.' : 'The browser did not grant persistent storage. ZIP backups still work.';
        });
    }
    return { init, size };
})();
