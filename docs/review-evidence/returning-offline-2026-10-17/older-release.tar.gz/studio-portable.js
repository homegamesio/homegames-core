'use strict';

// Storage/packaging adapter for the existing Studio editor. Game code only runs
// in the opaque iframe; the editor's text buffers and file tree stay authoritative.
window.StudioPortable = (() => {
    const p = HomegamesClient.PortableProject, enc = new TextEncoder(), dec = new TextDecoder('utf-8', {fatal:true});
    let store, record, timer, saving, serial = 0, dirty = false, conflict = false, frame, mediaUrl;
    let catalogPromise, creating = false, checkpointing = false, historyRequest = 0, copyShare;
    let saveHost, stoppingFrame = Promise.resolve();
    let assetUrls = [], listRequest = 0, assetRequest = 0, assetView = 'library', assetGameId = null, assetPageIndex = 0;
    const broadcast = typeof BroadcastChannel === 'function' ? new BroadcastChannel('homegames-studio-projects') : null;
    const active = () => currentGame?.portable && currentGame.id === record?.id;
    const status = text => { if ($('status-msg')) $('status-msg').textContent = text; };
    const error = value => { const text = value?.message || String(value); showError(text); status(active()&&dirty?'Not saved · keep this tab open':text); };
    const run = task => Promise.resolve().then(task).catch(error);
    function button(label, task, id) {
        const el = document.createElement('button'); el.className = 'dash-btn'; el.textContent = label;
        if (id) el.id = id; el.onclick = () => run(task); return el;
    }
    function validatePath(path) {
        if (p.normalizePath(path) !== path || /^\.homegame(?:\/|$)/i.test(path)) throw new Error('Choose a canonical project path outside .homegame/');
    }
    function files() {
        return validateFiles(Object.fromEntries(Object.entries(openFiles).map(([path,file])=>
            [path,file.bytes?.slice() || enc.encode(file.content)])));
    }
    function validateFiles(result) {
        const seen = new Set(); let total = 0;
        const names = Object.keys(result);
        if (names.length > p.limits.files) throw new Error('Too many project files');
        for (const path of names) {
            validatePath(path); const folded = path.toLowerCase();
            if (seen.has(folded)) throw new Error('Project paths must differ even ignoring capitalization');
            seen.add(folded);
            const data = result[path];
            if (data.length > p.limits.fileBytes || (total += data.length) > p.limits.totalBytes) throw new Error('Project size limit exceeded; your edits are still in the editor');
        }
        for (const name of seen) { const parts=name.split('/'); while(parts.length>1){parts.pop();if(seen.has(parts.join('/')))throw new Error('A file already uses that folder path');} }
        return result;
    }
    function decodeFile(path, bytes) {
        if (/\.(js|json|md|txt|css|html|csv|xml|yml|yaml)$/i.test(path) || /(^|\/)(LICENSE|README|ATTRIBUTION)$/i.test(path)) {
            try { const content=dec.decode(bytes);return {content,original:content,dirty:false,sha:null}; } catch (_) {}
        }
        return {content:'',bytes:new Uint8Array(bytes),original:'',dirty:false,sha:null};
    }
    async function list() {
        if (!store) return;
        const request=++listRequest, items=await store.list();if(request!==listRequest)return;
        const target=$('portable-project-list'); target.replaceChildren();
        const query=$('portable-search').value.trim().toLocaleLowerCase();
        target.dataset.filtered=String(!!query);
        for(const item of items.filter(item=>item.name.toLocaleLowerCase().includes(query)).sort((a,b)=>b.updatedAt-a.updatedAt)) {
            const card=button(item.name,()=>open(item.id));card.className='game-item portable-project';card.dataset.projectId=item.id;
            const date=document.createElement('small');date.textContent=new Date(item.updatedAt).toLocaleString();card.append(date);target.append(card);
        }
    }
    function showLibrary() {
        $('games-pane-header').textContent=''; $('new-game-btn').style.display='none';
        $('game-list-controls').style.display='none'; $('game-list-pager').style.display='none';
        $('game-list').replaceChildren();list().catch(error);
    }
    async function boot() {
        if(new URLSearchParams(location.hash.slice(1)).get('copy')==='1'){location.replace('/game-app.html'+location.search+location.hash);return;}
        enterGuestStudio();
        try {
            store=await StudioProjectStore.open();await list();
            StudioStorage.init(store,{save,open,download:downloadStored,remove:removeStored,assets:()=>openAssetModal()});
            $('portable-search').oninput=()=>list().catch(error);
            $('portable-new').disabled=$('portable-import').disabled=false;
            $('examples-open').disabled=$('portable-examples').disabled=false;
            const params=new URLSearchParams(location.search),id=params.get('project');
            if(id)await open(id);
            else if(params.has('builtin')) {
                const {project}=await HomegamesLibrary.loadProject(params.get('builtin'),p);
                const source=sourceFiles(project);source['homegame.json']=freshManifest(project);
                await install(await p.create(source));
                history.replaceState(null,'','/studio.html?'+new URLSearchParams({project:record.id}));
                status('Your own copy saved in this browser · export a ZIP to keep a backup');
            }
        } catch(e){error(e);}
        $('portable-new').onclick=()=>run(showTemplates);
        $('examples-open').onclick=$('portable-examples').onclick=()=>run(async()=>{await save();await stopFrame();stopPreview();await StudioExamples.open();});
        if(store && new URLSearchParams(location.search).get('examples')==='1') $('examples-open').click();
        /* Previous one-starter New game action retained during migration.
        $('portable-new').onclick=()=>run(async()=>{
            const response=await fetch('/studio-starter.zip');if(!response.ok)throw new Error('Could not load the starter');
            const project=await p.importArchive(new Uint8Array(await response.arrayBuffer()));
            const source=Object.fromEntries(project.reader.listFiles().map(name=>[name,project.reader.readFile(name)]));
            const manifest=JSON.parse(dec.decode(source['homegame.json']));manifest.gameId=crypto.randomUUID();source['homegame.json']=enc.encode(JSON.stringify(manifest,null,2));
            await install(await p.create(source));
        });
        */
        $('portable-import').onclick=()=>$('portable-zip-input').click();
        $('portable-zip-input').onchange=()=>run(async()=>{
            const file=$('portable-zip-input').files[0];$('portable-zip-input').value='';if(!file)return;
            if(file.size>p.limits.archiveBytes)throw new Error('Project ZIP is too large');
            const bytes=new Uint8Array(await file.arrayBuffer());
            if(StudioBackup.isBackup(bytes)) {
                const draft=StudioBackup.read(bytes,p);await installFiles(draft.files,draft.name,draft.activeFile);
                status('Studio draft restored as a new copy · fix any errors before playing');
            } else await install(await p.importArchive(bytes));
        });
        // $('portable-legacy').onclick=()=>{renderGuestTemplateList();};
        $('portable-template-close').onclick=()=>{$('portable-template-picker').hidden=true;};
        $('portable-recover').hidden=!loadGuestDraft()?.files;
        $('portable-recover').onclick=()=>run(recoverDraft);
        // if(broadcast)broadcast.onmessage=()=>list().catch(error);
        if(broadcast)broadcast.onmessage=()=>{list().catch(error);if(active())renderHistory().catch(error);};
    }
    function catalog() {
        if(!catalogPromise)catalogPromise=fetch('/studio-templates.json').then(async response=>{
            if(!response.ok)throw new Error('Could not load built-in templates');
            const data=await response.json();
            if(data.formatVersion!==1||!Array.isArray(data.templates))throw new Error('Unsupported template catalog');
            const ids=new Set();
            for(const t of data.templates){
                if(!/^[a-z0-9-]+$/.test(t.id)||ids.has(t.id)||typeof t.label!=='string'||typeof t.description!=='string'
                    ||!/^[a-f0-9]{64}$/.test(t.revision)||t.archive!==`${t.id}.${t.revision.slice(0,16)}.zip`)throw new Error('Invalid template catalog');
                ids.add(t.id);
            }
            return data.templates;
        }).catch(e=>{catalogPromise=null;throw e;});
        return catalogPromise;
    }
    async function templateProject(id) {
        const template=(await catalog()).find(t=>t.id===id);if(!template)throw new Error('Template not found');
        const response=await fetch('/studio-templates/'+template.archive);
        if(!response.ok)throw new Error('Could not load this template. Your existing projects are safe.');
        const project=await p.importArchive(new Uint8Array(await response.arrayBuffer()));
        if(project.revision!==template.revision)throw new Error('Template files changed. Reload Studio and try again.');
        return {template,project};
    }
    const sourceFiles=project=>Object.assign(Object.create(null),Object.fromEntries(project.reader.listFiles().map(path=>[path,project.reader.readFile(path)])));
    const freshManifest=project=>enc.encode(JSON.stringify({...project.manifest,gameId:crypto.randomUUID()},null,2)+'\n');
    async function showTemplates() {
        const templates=await catalog();setActiveBlade('games');
        const target=$('portable-template-list');target.replaceChildren();$('portable-template-picker').hidden=false;
        for(const t of templates){
            const card=button(t.label,()=>startTemplate(t.id));card.className='game-item portable-template';card.dataset.templateId=t.id;
            const description=document.createElement('small');description.textContent=t.description;card.append(description);target.append(card);
        }
        $('portable-template-picker').scrollIntoView({block:'nearest'});
    }
    async function startTemplate(id) {
        if(!store)throw new Error('Browser storage is unavailable. Reload Studio to try again.');
        if(creating)return;creating=true;
        try {
            const {project}=await templateProject(id),source=sourceFiles(project);
            source['homegame.json']=freshManifest(project);
            await install(await p.create(source));$('portable-template-picker').hidden=true;await play();
        } finally {creating=false;}
    }
    async function recoverDraft() {
        const draft=loadGuestDraft();if(!draft?.files)throw new Error('No previous guest draft found');
        if(creating)return;creating=true;
        try {
            const {template,project}=await templateProject(draft.templateId||'blank');
            // Keep the old localStorage copy. Incomplete/unsupported edits are
            // saved as a draft, never evaluated or discarded during recovery.
            const source=sourceFiles(project);delete source['index.js'];
            for(const [path,text] of Object.entries(draft.files)){
                if(typeof text!=='string')throw new Error('Previous draft contains an unsupported file');
                source[path]=enc.encode(text);
            }
            const oldSource=draft.files['index.js'];
            if(typeof oldSource==='string'){
                const digest=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',enc.encode(oldSource.replace(/\r\n/g,'\n').trim()))),n=>n.toString(16).padStart(2,'0')).join('');
                if(digest===template.legacySourceSha256)source['index.js']=project.reader.readFile('index.js');
                else if(template.id==='scroll')source['index.js']=enc.encode(oldSource.replace(/id:\s*(['"])f6f6df5eb5daa2313485a543679e5b38\1/g,"path: './assets/fella.png'"));
            }
            source['homegame.json']=freshManifest(project);
            await installFiles(source,String(draft.name||template.label).slice(0,100),'index.js');
            status('Previous draft recovered locally · original copy kept');
        } finally {creating=false;}
    }
    async function leave() {
        if(active())await save();
        else if(hasUnsavedChanges()&&!confirmDiscard())throw new Error('Kept your current edits');
    }
    async function install(project) {
        await installFiles(sourceFiles(project),project.metadata.name||'Untitled game',project.manifest.entry);
    }
    async function installFiles(source,name,activeFile) {
        validateFiles(source);
        await leave();
        const runtimeUrl=await StudioOffline.pinRuntime().catch(()=>undefined);
        const data=await store.write({id:crypto.randomUUID(),name,files:source,activeFile,runtimeUrl});
        await open(data.id);
    }
    async function open(id, discard=false) {
        const previous=record;
        status('Opening project…');
        if(!discard)await leave();else {clearTimeout(timer);if(saving)await saving.catch(()=>{});}
        if(record!==previous)return;
        const version=serial;
        const next=await store.read(id);if(!next)throw new Error('Project not found in this browser. Import a ZIP backup.');
        await stopFrame();
        if(record!==previous)return;
        if(!discard&&serial!==version)throw new Error('Your draft changed while opening a project. Edits kept; try opening it again.');
        clearTimeout(timer);stopPreview();previewOpen=false;record=next;dirty=false;conflict=false;
        currentGame={id:next.id,name:next.name,guest:true,portable:true};currentFile=null;viewingVersion=null;
        pendingDeletions=[];extraFolders=new Set();versions=[];
        openFiles=Object.fromEntries(Object.entries(next.files).map(([path,bytes])=>[path,decodeFile(path,bytes)]));
        fileTree=Object.keys(openFiles).map(path=>({path,type:'blob',sha:null}));editorBladeOpened=true;
        renderGameView();renderFileTree();updateSaveButton();renderGameBlade();
        switchToFile(Object.hasOwn(openFiles,next.activeFile)?next.activeFile:Object.keys(openFiles)[0]);setActiveBlade('editor');
        history.replaceState(null,'','?project='+encodeURIComponent(id));status('Saved in this browser');hideError();await list();
    }
    function changed() {
        if(viewingVersion)return;
        if(!active())return;dirty=true;serial++;clearTimeout(timer);status(conflict?'Conflicting save · edits kept in this tab':'Unsaved changes…');
        if(!conflict)timer=setTimeout(()=>save().catch(error),500);
    }
    function save() {
        clearTimeout(timer);
        if(viewingVersion)return Promise.resolve();
        if(!active())return Promise.resolve();
        if(conflict)return Promise.reject(new Error('Save your edits as a copy, or reload the saved version.'));
        if(saving)return saving.then(()=>dirty&&active()?save():undefined);
        if(!dirty&&!hasUnsavedChanges())return Promise.resolve();
        saving=(async()=>{
            do {
                const target=record,version=serial,source=files();status('Saving…');
                try {
                    const next=await store.write({...target,files:source,activeFile:currentFile?.path},target.generation);
                    target.generation=next.generation;target.files=source;target.updatedAt=next.updatedAt;
                    broadcast?.postMessage({id:target.id,generation:next.generation});
                    if(!active()||record!==target)return;
                    if(version===serial){dirty=false;for(const file of Object.values(openFiles)){file.dirty=false;file.original=file.content;}pendingDeletions=[];}
                } catch(e){if(e.code==='CONFLICT'){conflict=true;$('portable-conflict').hidden=false;}status('Not saved · keep this tab open');updateSaveButton();throw e;}
            } while(dirty&&active());
            renderTabs();renderFileTree();updateSaveButton();status('Saved in this browser');await list();
        })().finally(()=>{saving=null;});return saving;
    }
    function decorateEditor() {
        $('preview-toggle-btn').onclick=()=>run(play);
        // $('version-badge').textContent='BROWSER';$('commit-msg').style.display='none';
        $('version-badge').textContent=viewingVersion?'SNAPSHOT':'BROWSER';$('commit-msg').style.display='none';
        const dash=$('game-header').querySelector('.game-dashboard');
        dash.append(button('Versions',()=>setActiveBlade('game'),'portable-versions'));
        if(viewingVersion){
            dash.append(button('Current draft',()=>open(record.id,true),'portable-current-draft'));
            $('header-restore-btn').style.display='';
            $('header-restore-btn').onclick=()=>run(()=>restoreSnapshot(viewingVersion.id));
        }
        dash.append(button('Export ZIP',()=>exportProject(false),'portable-export-zip'),button('Download HTML',()=>exportProject(true),'portable-export-html'));
        dash.append(button('Share a copy',async()=>{await save();const project=await validated();copyShare?.close();copyShare=HomegamesClient.GameCopies.showCopyShare(project,{signalingUrl:sharing().signalingUrl,receiveUrl:new URL('/game-app.html',location.href).href});},'portable-share-copy'));
        const saveDownload=button('Download save',()=>saveHost.downloadSave('game-save.json'),'portable-save-download');
        const saveImport=button('Load save',()=>$('portable-save-file').click(),'portable-save-import');
        saveDownload.disabled=saveImport.disabled=true;
        const saveFile=document.createElement('input');saveFile.id='portable-save-file';saveFile.type='file';saveFile.accept='.json,application/json';saveFile.hidden=true;
        saveFile.onchange=()=>run(async()=>{
            const file=saveFile.files[0];saveFile.value='';if(!file||!saveHost)return;
            if(file.size>1024*1024+4096)throw new Error('Save file is too large');
            const text=await file.text();
            if(!confirm('Load this save and replace the current progress for this game?'))return;
            try {await saveHost.importSave(text);}catch(e){
                // A failed write may already have stopped the old runtime.
                // Relaunch the persisted progress, then show the import error.
                if(saveHost?.stopped)await play();throw e;
            }
            await play();
        });
        $('preview-controls').append(saveDownload,saveImport,saveFile);
        const controls=document.createElement('div');controls.id='portable-file-actions';
        const upload=document.createElement('input');upload.type='file';upload.hidden=true;upload.id='portable-file-input';
        let replace=false;
        controls.append(button('Add file',()=>{replace=false;upload.click();},'portable-add-file'),button('Replace file',()=>{replace=true;upload.click();},'portable-replace-file'),upload);
        upload.onchange=()=>run(async()=>{
            const file=upload.files[0];upload.value='';if(!file)return;
            const path=replace?currentFile?.path:prompt('Project path for this file','assets/'+file.name);if(!path)return;
            await addFile(file,path,replace);
        });
        $('editor-pane').insertBefore(controls,$('editor-tab-bar'));
        controls.hidden=!!viewingVersion;
        const conflictBar=document.createElement('div');conflictBar.id='portable-conflict';conflictBar.hidden=true;
        conflictBar.append('Another tab saved a newer version. Your edits are still here. ',button('Save edits as a copy',async()=>{
            const source=files();const copy=await store.write({...record,id:crypto.randomUUID(),name:record.name+' (copy)',files:source});
            dirty=false;conflict=false;for(const f of Object.values(openFiles))f.dirty=false;pendingDeletions=[];await open(copy.id);
        },'portable-save-copy'),button('Reload saved version',async()=>{if(confirm('Discard these unsaved edits and reload the saved version?'))await open(record.id,true);},'portable-reload'));
        $('main-content').insertBefore(conflictBar,$('editor-area'));
        const label=document.createElement('input');label.id='portable-name';label.value=viewingVersion?.name||record.name;label.maxLength=100;label.setAttribute('aria-label','Library name');
        label.disabled=!!viewingVersion;
        $('new-file-btn').hidden=!!viewingVersion;
        label.oninput=()=>{record.name=label.value.trim()||'Untitled game';currentGame.name=record.name;changed();};
        $('game-header').querySelector('.game-title').replaceWith(label);
    }
    function checkpointError(e) {
        if(e.code==='CONFLICT'){conflict=true;$('portable-conflict').hidden=false;updateSaveButton();}
        throw e;
    }
    async function snapshot() {
        if(!active()||viewingVersion||checkpointing)return;
        checkpointing=true;
        const target=record,message=$('portable-snapshot-message')?.value;
        try {
            await save();if(record!==target)return;
            await store.checkpoint(target.id,target.generation,message);
            broadcast?.postMessage({id:target.id});
            if(record===target){if($('portable-snapshot-message'))$('portable-snapshot-message').value='';await renderHistory();status('Snapshot saved in this browser');}
        } catch(e){if(record===target)checkpointError(e);else throw e;}
        finally{checkpointing=false;}
    }
    async function viewSnapshot(id) {
        status('Opening snapshot…');
        const target=record;await save();
        const snapshot=await store.readSnapshot(id);
        if(record!==target)return;
        if(!snapshot||snapshot.projectId!==record.id)throw new Error('Snapshot not found in this project');
        await stopFrame();
        // Edits made while reading the snapshot must reach the draft first.
        await save();if(record!==target)return;
        // The current draft stays in its own record. Viewing never writes it.
        stopPreview();previewOpen=false;viewingVersion={...snapshot,sha:snapshot.id};currentFile=null;
        openFiles=Object.fromEntries(Object.entries(snapshot.files).map(([path,bytes])=>[path,decodeFile(path,bytes)]));
        fileTree=Object.keys(openFiles).map(path=>({path,type:'blob',sha:null}));pendingDeletions=[];extraFolders=new Set();
        renderGameView();renderFileTree();updateSaveButton();
        switchToFile(Object.hasOwn(openFiles,snapshot.activeFile)?snapshot.activeFile:Object.keys(openFiles)[0]);
        setActiveBlade('editor');status('Read-only snapshot · '+snapshot.message);
    }
    async function restoreSnapshot(id) {
        if(!active()||checkpointing)return;
        if(!confirm('Restore this snapshot? Your current draft will be kept as a backup snapshot first.'))return;
        checkpointing=true;const target=record;
        try {
            await save();if(record!==target)return;
            const version=serial;
            const next=await store.checkpoint(target.id,target.generation,null,id);
            broadcast?.postMessage({id:target.id,generation:next.generation});
            if(record!==target)return;
            // Never discard edits entered while the storage transaction ran.
            if(serial!==version){const e=new Error('Snapshot restored in storage. New edits are still in this tab; save them as a copy or reload.');e.code='CONFLICT';throw e;}
            await open(target.id,true);status('Snapshot restored · previous draft kept in Versions');
        } catch(e){if(record===target)checkpointError(e);else throw e;}
        finally{checkpointing=false;}
    }
    async function renderHistory() {
        if(!active())return;
        const request=++historyRequest,target=record,items=await store.snapshots(target.id);
        if(record!==target||request!==historyRequest)return;
        const pendingName=$('portable-snapshot-form')?.dataset.projectId===target.id?$('portable-snapshot-message').value:'';
        renderGameBladeTitle();$('blade-game-label').textContent='Versions';
        const list=$('version-list');list.replaceChildren();$('version-panel-footer').replaceChildren();
        const intro=document.createElement('p');intro.className='portable-history-hint';
        intro.textContent='Your draft autosaves. Snapshots keep source and assets at a point in time. History stays in this browser; ZIP and HTML exports contain the selected version only.';
        list.append(intro,button('Open current draft',()=>open(target.id),'portable-open-draft'));
        const form=document.createElement('form');form.id='portable-snapshot-form';
        form.dataset.projectId=target.id;
        const name=document.createElement('input');name.id='portable-snapshot-message';name.maxLength=200;
        name.value=pendingName;
        name.placeholder='Snapshot name (optional)';name.setAttribute('aria-label','Snapshot name');
        const saveButton=button('Save snapshot',snapshot,'portable-snapshot-save');saveButton.type='submit';saveButton.onclick=null;
        saveButton.disabled=!!viewingVersion||conflict;
        form.onsubmit=event=>{event.preventDefault();run(snapshot);};form.append(name,saveButton);list.append(form);
        if(!items.length){const empty=document.createElement('p');empty.className='portable-history-hint';empty.textContent='No snapshots yet. Save one before trying a new idea.';list.append(empty);}
        for(const item of items.sort((a,b)=>b.createdAt-a.createdAt||b.generation-a.generation)){
            const row=document.createElement('div');row.className='version-item portable-snapshot';row.dataset.snapshotId=item.id;
            const title=document.createElement('strong');title.textContent=item.message;
            const date=document.createElement('small');date.textContent=new Date(item.createdAt).toLocaleString();
            const actions=document.createElement('div');actions.className='game-dashboard';
            actions.append(button('Open snapshot',()=>viewSnapshot(item.id)),button('Restore snapshot',()=>restoreSnapshot(item.id)));
            row.append(title,date,actions);list.append(row);
        }
    }
    function showMedia() {
        $('portable-media')?.remove();if(mediaUrl){URL.revokeObjectURL(mediaUrl);mediaUrl=null;}
        const file=openFiles[currentFile?.path];if(!file?.bytes)return false;
        $('editor-wrap').style.display='none';$('editor-placeholder').style.display='none';$('editor-textarea').style.display='none';setSyntaxError(null);
        const view=document.createElement('div');view.id='portable-media';
        const path=currentFile.path,image=/\.(png|jpe?g|webp|gif|bmp|avif)$/i.test(path),audio=/\.(wav|ogg|mp3|m4a|aac|flac|webm)$/i.test(path);
        if(image||audio){const element=document.createElement(image?'img':'audio');mediaUrl=URL.createObjectURL(new Blob([file.bytes]));element.src=mediaUrl;if(image)element.alt=path;else element.controls=true;view.append(element);}
        const info=document.createElement('p');info.textContent=`${path} · ${file.bytes.length.toLocaleString()} bytes`;view.append(info);$('editor-pane').append(view);return true;
    }
    async function addFile(file,path,replace=false) {
        if(viewingVersion)throw new Error('Open the current draft to add or replace files');
        if(!active())throw new Error('Open a browser project first');validatePath(path);
        if(!replace&&Object.hasOwn(openFiles,path))throw new Error('That path exists. Choose Replace file to change it.');
        if(file.size>p.limits.fileBytes)throw new Error('File exceeds the 16 MiB limit');
        const id=record.id,bytes=new Uint8Array(await file.arrayBuffer());if(!active()||id!==record.id)throw new Error('Project changed before the file was read');
        const prior=openFiles[path];openFiles[path]={...decodeFile(path,bytes),dirty:true};
        try{files();}catch(e){if(prior)openFiles[path]=prior;else delete openFiles[path];throw e;}
        if(!fileTree.some(file=>file.path===path))fileTree.push({path,type:'blob',sha:null});
        changed();renderFileTree();switchToFile(path);await save();return {id:path,name:path};
    }
    async function audioAssets() {return (await store.listAssets()).filter(asset=>asset.type==='audio');}
    async function assetBlob(asset) {const value=await store.readAsset(asset.id);if(!value)throw new Error('Asset was removed from My Assets');return new Blob([value.bytes]);}
    async function addAsset(file) {
        if(!store)throw new Error('Browser storage is unavailable');
        if(file.size>p.limits.fileBytes)throw new Error('Asset exceeds the 16 MiB limit');
        const name=file.name;validatePath('assets/'+name);
        if(name.includes('/'))throw new Error('Choose a filename without folders');
        const result=await store.addAsset(name,new Uint8Array(await file.arrayBuffer()),assetType(name));
        assetView='library';assetPageIndex=0;
        $('asset-library-feedback').textContent='Saved in My Assets. Add a copy to a game whenever you need it.';
        broadcast?.postMessage({assetId:result.id});return result;
    }
    function relocate(from,to) {
        try {
            if(viewingVersion)throw new Error('Open the current draft to rename files');
            validatePath(to);if(Object.hasOwn(openFiles,to))throw new Error('That file already exists');
            const data=openFiles[from];openFiles[to]=data;delete openFiles[from];
            try{files();}catch(e){openFiles[from]=data;delete openFiles[to];throw e;}
            fileTree=fileTree.map(file=>file.path===from?{...file,path:to}:file);data.dirty=true;
            if(currentFile?.path===from)currentFile={path:to};changed();renderFileTree();renderTabs();showEditor();
        }catch(e){error(e);}
    }
    async function validated() { try{return await p.create(files());}catch(e){throw new Error('Draft kept. Fix this before playing or exporting: '+e.message);} }
    async function runtime() {
        const current = new URL($('studio-runtime').src).pathname;
        // Use this Studio's player fixes for existing projects too. The pinned
        // runtime remains a fallback if the current one is unavailable offline.
        try { return await StudioOffline.runtime(current); }
        catch (error) { if (!record?.runtimeUrl || record.runtimeUrl === current) throw error; return StudioOffline.runtime(record.runtimeUrl); }
    }
    async function play() {
        // await save();const project=await validated();stopPreview();const generation=previewGeneration;
        await save();const project=await validated();await stopFrame();stopPreview();const generation=previewGeneration;
        if(!previewOpen)togglePreviewPanel();setPreviewStatus('Starting isolated preview…');
        const documentSource=await p.runtimeDocument(project,{clientBundleSource:await runtime(),installationId:record.id,sharing:sharing()});
        if(generation!==previewGeneration)return;
        // frame=p.createFrame(document,documentSource);$('preview-container').replaceChildren(frame);
        frame=p.createFrame(document,documentSource);const ownedFrame=frame;
        saveHost=p.attachPlayerHost(window,frame,{packageRevision:project.revision,installationId:record.id,gameId:project.manifest.gameId,
            versionId:'save-schema:'+project.manifest.saveSchemaVersion,compatibility:project.metadata.saveCompatibility||[],
            onStatus:value=>{if(frame===ownedFrame)setPreviewStatus(value.message);}});
        $('preview-container').replaceChildren(frame);
        $('portable-save-download').disabled=$('portable-save-import').disabled=false;
        $('preview-stop-btn').style.display='';$('preview-play-btn').textContent='Restart';
        // setPreviewStatus('Source saved locally · game progress lasts for this session');
        setPreviewStatus('Loading saved game progress…');
    }
    // function stopFrame(){if(frame){frame.remove();frame=null;}}
    function stopFrame(){
        if(frame){
            const old=frame,host=saveHost;frame=null;saveHost=null;
            // Keep the iframe in place until writes finish: reparenting an
            // iframe reloads its document. Editor transitions await this drain.
            // old.hidden=true;document.body.append(old);
            old.hidden=true;
            if($('portable-save-download'))$('portable-save-download').disabled=$('portable-save-import').disabled=true;
            const closing=(host?host.close():Promise.resolve()).finally(()=>old.remove());
            stoppingFrame=Promise.all([stoppingFrame,closing]).then(()=>{}).catch(error);
        }
        return stoppingFrame;
    }
    function sharing(){return {signalingUrl:window.HomegamesSiteConfig?.signalingUrl||'wss://api.homegames.io/rtc',joinUrl:new URL('/play.html',location.href).href};}
    function download(bytes,name,type='application/zip') {
        const url=URL.createObjectURL(new Blob([bytes],{type})),link=document.createElement('a');
        link.href=url;link.download=name;link.click();setTimeout(()=>URL.revokeObjectURL(url),30000);
    }
    async function downloadDraft(draft) {
        let project;
        try { project=await p.create(draft.files); } catch (_) {
            download(StudioBackup.create(draft,p),p.filename(draft.name).replace(/\.zip$/,'.studio.zip'));
            status('Studio draft backup downloaded · restore with Import ZIP');return;
        }
        download(await p.exportArchive(project),p.filename(draft.name));
    }
    async function downloadStored(id) {
        // A storage failure must never prevent rescuing the editor's bytes.
        const draft=active()&&record.id===id&&!viewingVersion?{...record,files:files()}:await store.read(id);
        if(!draft)throw new Error('This game was removed in another tab. Refresh storage.');
        await downloadDraft(draft);
    }
    async function removeStored(item) {
        const deletingCurrent=active()&&record.id===item.id;
        if(deletingCurrent){await save();await stopFrame();}
        await store.remove(item.id,item.generation);
        if(deletingCurrent){
            clearTimeout(timer);stopPreview();copyShare?.close();copyShare=null;
            record=null;currentGame=null;currentFile=null;viewingVersion=null;dirty=false;conflict=false;
            openFiles={};fileTree=[];pendingDeletions=[];extraFolders=new Set();versions=[];editorBladeOpened=false;previewOpen=false;
            $('main-content').replaceChildren();setActiveBlade('games');history.replaceState(null,'','/studio.html');
        }
        broadcast?.postMessage({id:item.id,deleted:true});await list();
    }
    async function exportProject(html) {
        if(!html){await downloadDraft({...record,name:viewingVersion?.name||record.name,files:files()});return;}
        const project=await validated();
        download(await p.buildIsolatedHtml(project,{clientBundleSource:await runtime(),installationId:crypto.randomUUID(),sharing:sharing()}),p.filename(project.metadata.name).replace(/\.zip$/,'.html'),'text/html');
    }
    function clearAssetPreviews() {assetRequest++;for(const url of assetUrls)URL.revokeObjectURL(url);assetUrls=[];}
    function resetAssetView(){assetView='library';assetGameId=record?.id||null;assetPageIndex=0;$('asset-library-feedback').textContent='';}
    function assetType(path) {
        return /\.(png|jpe?g|webp|gif|bmp|avif|svg)$/i.test(path)?'image':/\.(wav|ogg|mp3|m4a|aac|flac|webm)$/i.test(path)?'audio':/\.(ttf|otf|woff2?)$/i.test(path)?'font':'other';
    }
    function availableAssetPath(source,name) {
        const dot=name.lastIndexOf('.'),stem=dot>0?name.slice(0,dot):name,ext=dot>0?name.slice(dot):'';
        const paths=new Set(Object.keys(source).map(path=>path.toLowerCase()));
        if(paths.has('assets'))throw new Error('This game has a file named assets. Rename it before adding an assets folder.');
        for(let n=1;n<=p.limits.files+1;n++) {
            const path='assets/'+stem+(n===1?'':'-'+n)+ext;
            if(!paths.has(path.toLowerCase())&&![...paths].some(value=>value.startsWith(path.toLowerCase()+'/'))){validatePath(path);return path;}
        }
        throw new Error('Too many files in this game');
    }
    async function copyAssetToGame(asset,id) {
        const original=await store.readAsset(asset.id);if(!original)throw new Error('This library asset was removed in another tab.');
        if(active()&&record.id===id&&!viewingVersion) {
            await save();const path=availableAssetPath(files(),original.name);
            await addFile(new File([original.bytes],original.name),path);return path;
        }
        const target=await store.read(id);if(!target)throw new Error('Choose an existing game first.');
        const path=availableAssetPath(target.files,original.name);
        const source=validateFiles({...target.files,[path]:original.bytes});
        const next=await store.write({...target,files:source},target.generation);
        if(record?.id===id){record.generation=next.generation;record.files=next.files;record.updatedAt=next.updatedAt;}
        broadcast?.postMessage({id});await list();return path;
    }
    async function assets() {
        clearAssetPreviews();const request=assetRequest,projects=await store.list();
        if(!assetModalOpen||request!==assetRequest)return;
        if(!projects.some(item=>item.id===assetGameId))assetGameId=projects[0]?.id||null;
        const target=assetGameId===record?.id&&active()?{...record,files:files()}:assetGameId?await store.read(assetGameId):null;
        const summaries=assetView==='library'?await store.listAssets():Object.entries(target?.files||{}).filter(([path])=>path.startsWith('assets/')||assetType(path)!=='other').map(([path,bytes])=>({id:path,name:path,type:assetType(path),size:bytes.length,bytes}));
        if(!assetModalOpen||request!==assetRequest)return;
        const tabs=$('asset-modal-tabs');tabs.style.display='';tabs.replaceChildren();
        for(const [key,label] of [['library','My Assets'],['game','Game assets']]) {
            const tab=button(label,async()=>{assetView=key;assetPageIndex=0;await assets();},'asset-tab-'+key);
            tab.className='asset-modal-tab'+(assetView===key?' active':'');tab.setAttribute('aria-pressed',String(assetView===key));tabs.append(tab);
        }
        const destination=$('asset-library-destination');destination.replaceChildren();
        const label=document.createElement('label');label.textContent=assetView==='library'?'Add copies to ':'Game ';
        const select=document.createElement('select');select.id='asset-target-game';select.className='asset-modal-type-filter';select.setAttribute('aria-label','Destination game');
        if(!projects.length){const option=document.createElement('option');option.textContent='Create a game first';select.append(option);select.disabled=true;}
        for(const item of projects.sort((a,b)=>a.name.localeCompare(b.name))) {const option=document.createElement('option');option.value=item.id;option.textContent=item.name;select.append(option);}
        if(assetGameId)select.value=assetGameId;
        select.onchange=()=>{assetGameId=select.value;assetPageIndex=0;run(assets);};label.append(select);destination.append(label);
        const hint=document.createElement('small');hint.textContent=assetView==='library'?'Copies live in the game’s assets folder. Originals stay here.':'These files travel with the game’s ZIP. Save to My Assets to reuse one in another game.';destination.append(hint);
        $('asset-modal-type-filter').style.display='';$('asset-modal-nsfw-toggle').style.display='none';
        $('asset-upload-notice')?.classList.add('hidden');$('asset-modal-drop-zone').classList.remove('hidden');
        $('asset-modal-drop-zone').textContent='Drop files here or click to add to My Assets';
        for(const id of ['asset-modal-upload-btn','asset-modal-draw-btn','asset-modal-record-btn','asset-modal-keyboard-btn'])$(id).style.display='';
        const grid=$('asset-modal-grid');grid.replaceChildren();
        $('asset-modal-search').placeholder=assetView==='library'?'Search My Assets…':'Search game assets…';
        const matching=summaries.filter(asset=>asset.name.toLowerCase().includes(assetSearchQuery.toLowerCase())&&(!assetTypeFilter||asset.type===assetTypeFilter));
        assetPageIndex=Math.min(assetPageIndex,Math.max(0,Math.ceil(matching.length/20)-1));
        for(const asset of matching.slice(assetPageIndex*20,assetPageIndex*20+20)) {
            const library=assetView==='library',value=library?await store.readAsset(asset.id):asset;
            if(!assetModalOpen||request!==assetRequest)return;if(!value)continue;
            const {bytes}=value,type=asset.type;
            const item=document.createElement('article');item.className='asset-modal-card portable-asset';item.dataset.assetPath=asset.name;item.dataset.assetId=asset.id;
            const preview=document.createElement('div');preview.className='asset-modal-card-preview';
            const url=URL.createObjectURL(new Blob([bytes],{type:/\.svg$/i.test(asset.name)?'image/svg+xml':'application/octet-stream'}));assetUrls.push(url);
            if(type==='image') {const img=document.createElement('img');img.src=url;img.alt=asset.name;preview.append(img);}
            else if(type==='audio'){const audio=document.createElement('audio');audio.src=url;audio.controls=true;audio.preload='none';audio.setAttribute('aria-label',asset.name);preview.append(audio);}
            else {const badge=document.createElement('span');badge.className='type-badge';badge.textContent=type==='font'?'Aa':'File';preview.append(badge);}
            const body=document.createElement('div');body.className='asset-modal-card-body';
            const name=document.createElement('strong');name.className='asset-modal-card-name';name.textContent=asset.name.split('/').pop();name.title=asset.name;
            const detail=document.createElement('small');detail.className='asset-modal-card-author';detail.textContent=StudioStorage.size(bytes.byteLength)+(library?' · library original':' · '+asset.name);
            body.append(name,detail);
            const footer=document.createElement('div');footer.className='asset-modal-card-footer';
            const badge=document.createElement('span');badge.className='asset-modal-card-type '+type;badge.textContent=type;
            const controls=document.createElement('div');controls.className='asset-modal-card-actions';
            const code=path=>type==='other'?JSON.stringify('./'+path):`new Asset({ path: ${JSON.stringify('./'+path)}, type: '${type}' })`;
            if(library) {
                const add=button('Add to game',async()=>{
                    if(add.disabled)return;add.disabled=true;
                    try {const id=assetGameId,path=await copyAssetToGame(asset,id),game=projects.find(item=>item.id===id);
                        const feedback=$('asset-library-feedback');feedback.replaceChildren(document.createTextNode(`Added ${path} to ${game?.name||'game'}. `),button('Copy code',async()=>{await navigator.clipboard.writeText(code(path));status('Asset code copied');}));
                    } finally{add.disabled=!assetGameId;}
                });add.classList.add('asset-add-button');add.disabled=!assetGameId;controls.append(add);
            } else {
                controls.append(button('Save to My Assets',async()=>{await addAsset(new File([bytes],asset.name.split('/').pop()));await assets();}),button('Copy code',async()=>{await navigator.clipboard.writeText(code(asset.name));$('asset-library-feedback').textContent='Asset code copied.';}));
            }
            controls.append(button('Download',()=>download(bytes,asset.name.split('/').pop(),'application/octet-stream')));
            if(library||!(viewingVersion&&assetGameId===record?.id))controls.append(button('Delete',async()=>{
                if(!confirm(library?`Delete “${asset.name}” from My Assets? Copies already added to games are kept.`:`Delete “${asset.name}” from this game? Its library original is kept. Code using it will need updating.`))return;
                if(library)await store.removeAsset(asset.id);
                else if(active()&&record.id===target.id){deleteFile(asset.name);await save();}
                else {const source={...target.files};delete source[asset.name];await store.write({...target,files:source},target.generation);}
                await list();await assets();
            }));
            footer.append(badge,controls);item.append(preview,body,footer);grid.append(item);
        }
        if(!grid.children.length){const empty=document.createElement('p');empty.className='asset-modal-empty';empty.textContent=assetSearchQuery||assetTypeFilter?'No assets match your search.':assetView==='library'?'Your asset library is empty. Upload, draw or record something to use across your games.':'No assets in this game yet. Choose My Assets, then Add to game.';grid.append(empty);}
        const pager=$('asset-modal-load-more');pager.replaceChildren();
        if(matching.length>20){const prev=button('Previous',async()=>{assetPageIndex--;await assets();}),next=button('Next',async()=>{assetPageIndex++;await assets();});prev.disabled=assetPageIndex===0;next.disabled=(assetPageIndex+1)*20>=matching.length;pager.append(prev,` ${assetPageIndex+1} / ${Math.ceil(matching.length/20)} `,next);}
    }
    window.addEventListener('beforeunload',event=>{if(active()&&dirty){event.preventDefault();event.returnValue='';}});
    window.addEventListener('pagehide',()=>copyShare?.close());
    async function copyExample(project) {
        const source=sourceFiles(project);source['homegame.json']=freshManifest(project);
        await install(await p.create(source));await play();
    }
    return {boot,list,showLibrary,showTemplates,changed,save,decorateEditor,showMedia,validatePath,relocate,play,stopFrame,assets,addAsset,audioAssets,error,copyExample,open,
        clearAssetPreviews,resetAssetView,assetBlob,renderHistory,snapshot,viewSnapshot,restoreSnapshot,openCurrent:()=>open(record.id),
        get storageReady(){return !!store;},get conflicted(){return conflict;},templatesLoaded:false};
})();
