'use strict';
const CACHE = 'homegames-game-shell-1300dc3da3dbfa9a';
const ASSETS = ["/game-app.html","/game-app.js","/game-app.css","/game-app-storage.js","/studio-project-store.js","/site-config.js","/homegames-client.fca6d9bd45c4d569.js","/apple-touch-icon.png","/android-chrome-192x192.png","/android-chrome-512x512.png","/game-app-catalog.json"];
self.addEventListener('install', event => event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(ASSETS))));
self.addEventListener('activate', event => event.waitUntil((async () => {
    for (const name of await caches.keys()) if (name.startsWith('homegames-game-shell-') && name !== CACHE) await caches.delete(name);
    await self.clients.claim();
})()));
self.addEventListener('fetch', event => {
    const request = event.request, url = new URL(request.url);
    if (request.method !== 'GET' || url.origin !== self.location.origin) return;
    // Private game HTML is read by the trusted player only; never serve peer
    // HTML as a same-origin document. Manifests contain data, not game code.
    if (url.pathname === '/game-app-manifest.webmanifest') {
        event.respondWith(caches.open('homegames-game-manifests-v1').then(async cache =>
            await cache.match(request) || new Response('{}', { status: 404, headers: { 'Content-Type': 'application/manifest+json' } })));
        return;
    }
    if (url.pathname === '/game-app-icon.png') {
        event.respondWith(caches.open('homegames-game-icons-v1').then(async cache =>
            await cache.match(request) || new Response('', { status: 404 })));
        return;
    }
    const navigation = request.mode === 'navigate' && url.pathname === '/game-app.html';
    if (!navigation && !ASSETS.includes(url.pathname)) return;
    event.respondWith(caches.open(CACHE).then(async cache => await cache.match(navigation ? '/game-app.html' : url.pathname) || fetch(request)));
});
