window.HomegamesSiteConfig = {"signalingUrl":"wss://api.homegames.io/rtc","runtimeUrl":"/homegames-client.fca6d9bd45c4d569.js"};
