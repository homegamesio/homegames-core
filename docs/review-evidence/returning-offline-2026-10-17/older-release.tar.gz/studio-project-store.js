'use strict';

// Studio's private database is never exposed to the game iframe. Storage accepts
// unfinished drafts (including syntax errors); play/export validate separately.
window.StudioProjectStore = class StudioProjectStore {
    // Fork the exact verified package, including binary assets and licenses.
    // Keep player storage and the original game identity separate from edits.
    static async copyGame(project, portable, runtimeUrl) {
        const files = Object.fromEntries(project.reader.listFiles().map(path => [path, project.reader.readFile(path).slice()]));
        files['homegame.json'] = new TextEncoder().encode(JSON.stringify({ ...project.manifest, gameId: crypto.randomUUID() }, null, 2) + '\n');
        const copy = await portable.create(files);
        const store = await this.open();
        try {
            return await store.write({ id: crypto.randomUUID(), name: copy.metadata.name || 'Untitled game',
                files, activeFile: copy.manifest.entry, runtimeUrl });
        } finally { store.database.close(); }
    }
    static open() {
        return new Promise((resolve, reject) => {
            let blocked = false;
            // Version 1 contained drafts only. Keep those stores and their data.
            // const request = indexedDB.open('homegames-studio-projects', 1);
            const request = indexedDB.open('homegames-studio-projects', 3);
            request.onupgradeneeded = event => {
                if (event.oldVersion < 1) {
                    request.result.createObjectStore('projects', { keyPath: 'id' });
                    request.result.createObjectStore('summaries', { keyPath: 'id' });
                }
                if (event.oldVersion < 2) for (const name of ['snapshots', 'snapshotSummaries']) {
                    request.result.createObjectStore(name, { keyPath: 'id' }).createIndex('projectId', 'projectId');
                }
                if (event.oldVersion < 3) for (const name of ['assets', 'assetSummaries']) {
                    request.result.createObjectStore(name, { keyPath: 'id' });
                }
            };
            request.onerror = () => reject(request.error);
            // request.onblocked = () => reject(new Error('Close other Studio tabs to update local storage, then reload.'));
            // request.onsuccess = () => resolve(new StudioProjectStore(request.result));
            request.onblocked = () => { blocked = true; reject(new Error('Close other Studio tabs to update local storage, then reload.')); };
            request.onsuccess = () => { if (blocked) request.result.close(); else resolve(new StudioProjectStore(request.result)); };
        });
    }
    constructor(database) {
        this.database = database;
        database.onversionchange = () => database.close();
    }
    read(id) {
        return this.query('projects', store => store.get(id));
    }
    list() { return this.query('summaries', store => store.getAll()); }
    listAssets() { return this.query('assetSummaries', store => store.getAll()); }
    readAsset(id) { return this.query('assets', store => store.get(id)); }
    addAsset(name, bytes, type) {
        return new Promise((resolve, reject) => {
            const tx = this.database.transaction(['assets', 'assetSummaries'], 'readwrite');
            const summary = { id: crypto.randomUUID(), name, type, size: bytes.byteLength, createdAt: Date.now() };
            tx.objectStore('assets').add({ ...summary, bytes }); tx.objectStore('assetSummaries').add(summary);
            tx.oncomplete = () => resolve(summary);
            tx.onabort = () => reject(tx.error || new Error('Could not save the asset. Your original file is unchanged.'));
        });
    }
    removeAsset(id) {
        return new Promise((resolve, reject) => {
            const tx = this.database.transaction(['assets', 'assetSummaries'], 'readwrite');
            tx.objectStore('assets').delete(id); tx.objectStore('assetSummaries').delete(id);
            tx.oncomplete = () => resolve();
            tx.onabort = () => reject(tx.error || new Error('Could not delete the library asset'));
        });
    }
    // Read one record at a time; do not retain every game's media in memory.
    usage() {
        return new Promise((resolve, reject) => {
            const tx = this.database.transaction(['projects', 'snapshots'], 'readonly');
            const projects = new Map(), history = new Map();
            const size = files => Object.values(files).reduce((sum, data) => sum + data.byteLength, 0);
            const drafts = tx.objectStore('projects').openCursor();
            drafts.onsuccess = () => {
                const cursor = drafts.result; if (!cursor) return;
                const { id, name, generation, updatedAt, files } = cursor.value;
                projects.set(id, { id, name, generation, updatedAt, bytes: size(files), fileCount: Object.keys(files).length });
                cursor.continue();
            };
            const snapshots = tx.objectStore('snapshots').openCursor();
            snapshots.onsuccess = () => {
                const cursor = snapshots.result; if (!cursor) return;
                const { projectId, files } = cursor.value;
                const item = history.get(projectId) || { snapshotBytes: 0, snapshotCount: 0 };
                item.snapshotBytes += size(files); item.snapshotCount++; history.set(projectId, item);
                cursor.continue();
            };
            tx.oncomplete = () => resolve([...projects.values()].map(item => ({ ...item,
                ...(history.get(item.id) || { snapshotBytes: 0, snapshotCount: 0 }) })));
            tx.onabort = () => reject(tx.error || new Error('Could not measure saved games'));
        });
    }
    remove(id, expectedGeneration) {
        return new Promise((resolve, reject) => {
            const tx = this.database.transaction(['projects', 'summaries', 'snapshots', 'snapshotSummaries'], 'readwrite');
            let error;
            const request = tx.objectStore('projects').get(id);
            request.onsuccess = () => {
                if (!request.result || request.result.generation !== expectedGeneration) {
                    error = new Error('This game changed in another tab. Refresh storage before deleting it.');
                    error.code = 'CONFLICT'; tx.abort(); return;
                }
                tx.objectStore('projects').delete(id); tx.objectStore('summaries').delete(id);
                for (const name of ['snapshots', 'snapshotSummaries']) {
                    const cursor = tx.objectStore(name).index('projectId').openCursor(id);
                    cursor.onsuccess = () => { if (cursor.result) { cursor.result.delete(); cursor.result.continue(); } };
                }
            };
            tx.oncomplete = () => resolve();
            tx.onabort = () => reject(error || tx.error || new Error('Could not delete this game'));
        });
    }
    snapshots(projectId) { return this.query('snapshotSummaries', store => store.index('projectId').getAll(projectId)); }
    readSnapshot(id) { return this.query('snapshots', store => store.get(id)); }
    // Check the saved draft's generation in the same transaction as its snapshot.
    // Restore also keeps a full backup; quota errors abort ALL of these writes.
    checkpoint(projectId, expectedGeneration, message, restoreId = null) {
        return new Promise((resolve, reject) => {
            const tx = this.database.transaction(['projects', 'summaries', 'snapshots', 'snapshotSummaries'], 'readwrite');
            let result, error;
            const abort = message => { error = new Error(message); tx.abort(); };
            const guard = action => () => {
                try { action(); }
                catch (e) { error = e; try { tx.abort(); } catch (_) { /* Already aborted. */ } }
            };
            const request = tx.objectStore('projects').get(projectId);
            const keep = (record, title) => {
                const snapshot = { id: crypto.randomUUID(), projectId, name: record.name, files: record.files,
                    activeFile: record.activeFile, generation: record.generation, createdAt: Date.now(), message: title.slice(0, 200) };
                tx.objectStore('snapshots').add(snapshot);
                const { files, ...summary } = snapshot;
                tx.objectStore('snapshotSummaries').add(summary);
                return summary;
            };
            request.onsuccess = guard(() => {
                const current = request.result;
                if (!current) return abort('Project not found in this browser');
                if (current.generation !== expectedGeneration) {
                    error = new Error('Another tab saved this project. Save your edits as a copy, or reload the saved version.');
                    error.code = 'CONFLICT'; tx.abort(); return;
                }
                if (!restoreId) {
                    result = keep(current, String(message || 'Snapshot').trim().slice(0, 200) || 'Snapshot');
                    return;
                }
                const prior = tx.objectStore('snapshots').get(restoreId);
                prior.onsuccess = guard(() => {
                    const snapshot = prior.result;
                    if (!snapshot || snapshot.projectId !== projectId) return abort('Snapshot not found in this project');
                    keep(current, 'Before restore: ' + snapshot.message);
                    result = { ...current, name: snapshot.name, files: snapshot.files, activeFile: snapshot.activeFile,
                        generation: current.generation + 1, updatedAt: Date.now() };
                    tx.objectStore('projects').put(result);
                    tx.objectStore('summaries').put({ id: result.id, name: result.name, generation: result.generation, updatedAt: result.updatedAt });
                });
            });
            tx.oncomplete = () => resolve(result);
            tx.onabort = () => reject(error || tx.error || new Error('Browser storage could not save the snapshot'));
        });
    }
    query(name, run) {
        return new Promise((resolve, reject) => {
            const tx = this.database.transaction(name, 'readonly');
            const request = run(tx.objectStore(name));
            tx.oncomplete = () => resolve(request.result);
            tx.onabort = () => reject(tx.error || new Error('Could not read browser storage'));
        });
    }
    // Compare-and-swap in ONE transaction. No async hashing or rendering while
    // the transaction is active. A failed write never claims success in the UI.
    write(record, expectedGeneration = null) {
        return new Promise((resolve, reject) => {
            const tx = this.database.transaction(['projects', 'summaries'], 'readwrite');
            const store = tx.objectStore('projects');
            let next, error;
            const request = store.get(record.id);
            request.onsuccess = () => {
                const current = request.result;
                if ((current?.generation ?? null) !== expectedGeneration) {
                    error = new Error('Another tab saved this project. Save your edits as a copy, or reload the saved version.');
                    error.code = 'CONFLICT'; tx.abort(); return;
                }
                next = { ...record, generation: (expectedGeneration || 0) + 1, updatedAt: Date.now() };
                store.put(next);
                tx.objectStore('summaries').put({ id: next.id, name: next.name, generation: next.generation, updatedAt: next.updatedAt });
            };
            tx.oncomplete = () => resolve(next);
            tx.onabort = () => reject(error || tx.error || new Error('Browser storage could not save your project'));
        });
    }
};
