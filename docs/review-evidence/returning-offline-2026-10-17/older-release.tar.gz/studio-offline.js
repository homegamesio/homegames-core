'use strict';
// Offline support for the existing Studio, using its existing project database.
window.StudioOffline = (() => {
    const RUNTIMES = 'homegames-studio-runtimes-v1';
    const status = text => { document.getElementById('studio-offline-status').textContent = text; };
    async function prepare() {
        if (!navigator.serviceWorker || !window.isSecureContext) throw new Error('Offline Studio needs HTTPS. Projects can still be exported as ZIP backups.');
        const previous = await navigator.serviceWorker.getRegistration('/studio.html');
        const registration = await navigator.serviceWorker.register('/studio-sw.js', { scope: '/studio', updateViaCache: 'none' }).catch(e => { if (previous?.active) return previous; throw e; });
        if (!registration.active) await new Promise((resolve, reject) => {
            const timer = setTimeout(() => reject(new Error('Offline preparation did not finish. Check your connection and reload Studio.')), 30000);
            navigator.serviceWorker.ready.then(() => { clearTimeout(timer); resolve(); });
            registration.installing?.addEventListener('statechange', event => {
                if (event.target.state === 'redundant') { clearTimeout(timer); reject(new Error('Could not save Studio for offline use. Check device storage and reload.')); }
            });
        });
        status('Studio is ready offline · projects stay on this device');
    }
    const readiness = prepare().then(() => true, e => { status(e.message); return false; });
    async function runtime(url, keep = false) {
        if (!/^\/homegames-client\.[a-f0-9]{16}\.js$/.test(url)) throw new Error('Invalid game runtime');
        const cache = typeof caches === 'undefined' ? null : await caches.open(RUNTIMES).catch(() => null);
        if (keep && !cache) throw new Error('This browser could not keep the runtime offline. Export a ZIP backup.');
        let response = await cache?.match(url);
        if (!response) {
            response = await fetch(url);
            if (!response.ok) throw new Error('Could not load the game runtime. Reconnect and try again.');
            if (keep) await cache.put(url, response.clone());
        }
        return response.text();
    }
    async function pinRuntime() {
        if (!await readiness) throw new Error('Studio is not ready offline. Export a ZIP backup and reload to try again.');
        const url = HomegamesSiteConfig.runtimeUrl; await runtime(url, true); return url;
    }
    return { runtime, pinRuntime, readiness };
})();
