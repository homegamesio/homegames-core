'use strict';
const CACHE = 'homegames-studio-shell-c22be913d2788d47';
const ASSETS = ["/studio.html","/studio.js","/studio-portable.js","/studio-portable.css","/studio-project-store.js","/studio-storage.js","/assets/homegames-logo.png","/studio-offline.js","/studio.webmanifest","/studio-examples.js","/studio-examples.css","/studio-templates.json","/studio-examples.json","/bundle.js","/site-config.js","/homegames-client.fca6d9bd45c4d569.js","/amateur.ttf","/authoring-guide.md","/apple-touch-icon.png","/android-chrome-192x192.png","/android-chrome-512x512.png","/studio-templates/animation.4d6c91187da4d372.zip","/studio-templates/blank.66eeb4ec790737c5.zip","/studio-templates/buttons.4688f25635ea96b9.zip","/studio-templates/click.99653c0683ea2966.zip","/studio-templates/glow.6fdcb679d3ffb878.zip","/studio-templates/image.c8a312985c3489d0.zip","/studio-templates/keyboard.7717fc7ea906135e.zip","/studio-templates/multiplayer.4e9d655e28e1492c.zip","/studio-templates/pocket-chime.d298f78bdb6aefe9.zip","/studio-templates/scroll.417dc1ede75f1287.zip","/studio-templates/text-input.8832614089014d44.zip","/studio-examples/click.43d662c248b7b3b6.zip","/studio-examples/drag.aae6ced91c78d3ba.zip","/studio-examples/move.9e9ff7827f5d5b70.zip","/studio-examples/sound.7200d27a4d955f47.zip","/studio-examples/square.2b92d5def1158134.zip","/studio-examples/together.38072c1472a0a399.zip"];
const RUNTIMES = 'homegames-studio-runtimes-v1';
self.addEventListener('install', event => {
    event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(ASSETS)));
});
self.addEventListener('activate', event => {
    event.waitUntil((async () => {
        for (const name of await caches.keys()) if (name.startsWith('homegames-studio-shell-') && name !== CACHE) await caches.delete(name);
        await self.clients.claim();
    })());
});
self.addEventListener('fetch', event => {
    const request = event.request, url = new URL(request.url);
    if (request.method !== 'GET' || url.origin !== self.location.origin) return;
    const navigation = request.mode === 'navigate' && ['/studio.html', '/studio'].includes(url.pathname);
    const runtime = /^\/homegames-client\.[a-f0-9]{16}\.js$/.test(url.pathname);
    if (!navigation && !runtime && !ASSETS.includes(url.pathname)) return;
    event.respondWith((async () => {
        const key = navigation ? '/studio.html' : url.pathname;
        const cache = await caches.open(CACHE);
        const response = await cache.match(key) || (runtime ? await (await caches.open(RUNTIMES)).match(key) : null);
        return response || fetch(request);
    })());
});
